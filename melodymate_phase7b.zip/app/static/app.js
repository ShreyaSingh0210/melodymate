// MelodyMate singing page. Messages go into #status (an aria-live region).
// Focus is never moved by this script. Nothing plays or records unless a button is pressed.
const $ = (id) => document.getElementById(id);
const status = $("status");
const melody = $("melody"), mode = $("mode"), phones = $("phones"), speak = $("speak");
const practiceBtn = $("practice"), play = $("play"), start = $("start"), stop = $("stop");
let state = "idle"; // idle | busy | playing | recording
let rec = null;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const setOn = (btn, on) => btn.setAttribute("aria-disabled", on ? "false" : "true");

function say(text) {
  status.textContent = text;
  if (speak.checked && "speechSynthesis" in window) {   // opt-in speech for people without a screen reader
    speechSynthesis.cancel();
    speechSynthesis.speak(new SpeechSynthesisUtterance(text));
  }
}

function refresh() {
  setOn(play, state === "idle");
  setOn(practiceBtn, state === "idle" && phones.checked);
  setOn(start, state === "idle" && phones.checked);
  setOn(stop, state === "recording");
}

// aria-disabled keeps the button focusable, so focus never jumps when a button turns off.
function onPress(btn, reason, fn) {
  btn.addEventListener("click", () => {
    if (btn.getAttribute("aria-disabled") === "true") { say(reason()); return; }
    fn();
  });
}
const idleReason = () => state === "idle"
  ? "Tick the headphones box first. Without headphones, the microphone hears the reference melody."
  : "Wait until the current step has finished.";

async function loadMelodies() {
  try {
    const list = await (await fetch("/api/melodies")).json();
    list.forEach((m) => melody.add(new Option(m.label, m.id)));
  } catch { say("The melody list could not be loaded. Check that the server is running."); }
}

async function playRef() {
  const r = await fetch("/api/reference/" + encodeURIComponent(melody.value));
  if (!r.ok) throw new Error("The reference melody could not be loaded.");
  const url = URL.createObjectURL(await r.blob());
  const audio = new Audio(url);
  await new Promise((resolve, reject) => { audio.onended = resolve; audio.onerror = reject; audio.play().catch(reject); });
  URL.revokeObjectURL(url);
}

async function beep(times) {
  const ctx = new AudioContext();
  for (let i = 0; i < times; i++) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.value = 880; g.gain.value = 0.2;
    o.connect(g); g.connect(ctx.destination); o.start();
    await sleep(180); o.stop(); await sleep(150);
  }
  await ctx.close();
}

async function playReference() {
  state = "playing"; refresh(); say("Playing the reference melody.");
  try { await playRef(); say("The reference melody has finished."); }
  catch { say("The reference melody could not be played."); }
  state = "idle"; refresh();
}

// Opens the microphone but keeps the recording switched off until beginCapture().
async function openMic() {
  if (!navigator.mediaDevices || !window.AudioWorkletNode) {
    throw Object.assign(new Error("This browser cannot record here. Use Chrome or Edge, opened at http://127.0.0.1:8000."), { name: "Unsupported" });
  }
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
  });
  const ctx = new AudioContext();
  const code = "class R extends AudioWorkletProcessor{process(i){const c=i[0][0];if(c)this.port.postMessage(c.slice());return true}}registerProcessor('rec',R)";
  const modUrl = URL.createObjectURL(new Blob([code], { type: "application/javascript" }));
  await ctx.audioWorklet.addModule(modUrl);
  URL.revokeObjectURL(modUrl);
  const r = { stream, ctx, chunks: [], active: false, auto: false, heard: false, last: 0, t0: 0, stopping: false };
  const node = new AudioWorkletNode(ctx, "rec");
  node.port.onmessage = (e) => {
    if (!r.active) return;
    r.chunks.push(e.data);
    if (!r.auto || r.stopping) return;
    let s = 0; for (const x of e.data) s += x * x;
    const now = performance.now();
    if (Math.sqrt(s / e.data.length) > 0.01) { r.heard = true; r.last = now; }
    const quiet = r.heard && now - r.last > 2000;      // two seconds of silence after singing
    const noSound = !r.heard && now - r.t0 > 12000;    // nothing sung for 12 seconds
    if (quiet || noSound || now - r.t0 > 45000) { r.stopping = true; stopAndAnalyze(); }
  };
  const mute = ctx.createGain(); mute.gain.value = 0;  // keeps the audio graph running, makes no sound
  ctx.createMediaStreamSource(stream).connect(node);
  node.connect(mute); mute.connect(ctx.destination);
  return r;
}

function beginCapture(auto) {
  rec.active = true; rec.auto = auto; rec.t0 = rec.last = performance.now();
  state = "recording"; refresh();
}

function closeMic() {
  if (!rec) return;
  rec.stream.getTracks().forEach((t) => t.stop());
  rec.ctx.close().catch(() => {});
  rec = null;
}

function micMessage(err) {
  const n = err && err.name;
  return n === "NotAllowedError" ? "Microphone permission was denied. Allow the microphone for this page in the browser, then try again."
    : n === "NotFoundError" ? "No microphone was found. Connect one and try again."
    : (err && err.message) || "Recording could not start.";
}

async function startRecording() {
  state = "busy"; refresh(); say("Waiting for the microphone.");
  try {
    rec = await openMic();
    beginCapture(false);
    say("Recording. Sing the melody, then press Stop and analyze.");
  } catch (err) { closeMic(); state = "idle"; refresh(); say(micMessage(err)); }
}

// One press: listen, two beeps, record until silence, analyze.
async function practice() {
  state = "busy"; refresh();
  say("Listen to the melody. After two beeps, sing it. Recording stops after two seconds of silence.");
  try {
    rec = await openMic();
    await sleep(speak.checked ? 7000 : 4500);   // time for the message to be heard before the melody starts
    state = "playing"; refresh();
    await playRef();
    await sleep(500);
    await beep(2);
    beginCapture(true);
  } catch (err) { closeMic(); state = "idle"; refresh(); say(micMessage(err)); }
}

function encodeWav(chunks, total, rate) {
  const buf = new ArrayBuffer(44 + total * 2), v = new DataView(buf);
  const str = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  str(0, "RIFF"); v.setUint32(4, 36 + total * 2, true); str(8, "WAVE"); str(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  str(36, "data"); v.setUint32(40, total * 2, true);
  let o = 44;
  for (const c of chunks) for (let i = 0; i < c.length; i++, o += 2) {
    const s = Math.max(-1, Math.min(1, c[i]));
    v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Blob([buf], { type: "audio/wav" });
}

async function stopAndAnalyze() {
  if (!rec) return;
  const { chunks, auto } = rec; rec.active = false;
  const rate = rec.ctx.sampleRate;
  state = "busy"; refresh();
  closeMic();
  if (auto) await beep(1);   // one beep tells the singer the recording has ended
  const total = chunks.reduce((n, c) => n + c.length, 0);
  if (total < rate) {
    state = "idle"; refresh();
    say("The recording was shorter than one second. Try again."); return;
  }
  say("Analyzing your singing. This takes a few seconds.");
  const form = new FormData();
  form.append("file", encodeWav(chunks, total, rate), "recording.wav");
  form.append("melody", melody.value);
  form.append("mode", mode.value);
  try {
    const r = await fetch("/api/analyze/singing", { method: "POST", body: form });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.detail || "The server could not analyze the recording.");
    const notes = data.detected_notes.length ? " Notes heard: " + data.detected_notes.join(", ") + "." : "";
    say(data.feedback + notes);
  } catch (err) { say("Analysis failed. " + err.message); }
  state = "idle"; refresh();
}

onPress(practiceBtn, idleReason, practice);
onPress(play, () => "Wait until the current step has finished.", playReference);
onPress(start, idleReason, startRecording);
onPress(stop, () => "Recording has not started.", stopAndAnalyze);
phones.addEventListener("change", refresh);
loadMelodies(); refresh();

// MelodyMate singing page. Focus is never moved by this script.
// Nothing plays or records unless a button is pressed.
const $ = (id) => document.getElementById(id);
const status = $("status"), details = $("details");
const melody = $("melody"), mode = $("mode"), phones = $("phones"), speak = $("speak"), rate = $("rate");
const voiceBtn = $("voice"), practiceBtn = $("practice"), play = $("play"), start = $("start"), stop = $("stop");
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
const NOTHING = "I did not hear any singing. Check that your microphone is on, and sing a little louder.";
let state = "idle"; // idle | busy | playing | recording
let rec = null, inSession = false, cancelled = false, talkToken = 0, onResult = null, abortListen = null;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const setOn = (btn, on) => btn.setAttribute("aria-disabled", on ? "false" : "true");
const guard = () => { if (cancelled) throw new Error("cancelled"); };

// ---- speaking (slow, one sentence at a time with short pauses) ----
function speakOne(s) {
  return new Promise((res) => {
    const u = new SpeechSynthesisUtterance(s);
    u.rate = Number(rate.value); u.lang = navigator.language || "en-US";
    u.onend = u.onerror = res;
    speechSynthesis.speak(u);
  });
}
async function talk(text) {
  if (inSession) status.textContent = text;
  if (!("speechSynthesis" in window)) return;
  const my = ++talkToken;
  speechSynthesis.cancel();
  for (const s of text.split(/(?<=[.?!])\s+/)) {
    if (my !== talkToken) return;
    await speakOne(s);
    await sleep(400);
  }
}
function say(text) {
  status.textContent = text;
  if (!inSession && speak.checked) talk(text);   // opt-in speech for people without a screen reader
}

function refresh() {
  setOn(voiceBtn, state === "idle");
  setOn(play, state === "idle");
  setOn(practiceBtn, state === "idle" && phones.checked);
  setOn(start, state === "idle" && phones.checked);
  setOn(stop, state === "recording");
}
const idle = () => { state = inSession ? "busy" : "idle"; refresh(); };

// aria-disabled keeps the button focusable, so focus never jumps when a button turns off.
function onPress(btn, reason, fn) {
  btn.addEventListener("click", () => {
    if (btn.getAttribute("aria-disabled") === "true") { say(reason()); return; }
    fn();
  });
}
const idleReason = () => state === "idle"
  ? "Tick the headphones box first. Without headphones, the microphone hears the reference melody."
  : "Wait until the current step has finished.";

async function loadMelodies() {
  try {
    const list = await (await fetch("/api/melodies")).json();
    list.forEach((m) => melody.add(new Option(m.label, m.id)));
  } catch { say("The melody list could not be loaded. Check that the server is running."); }
}

async function playRef() {
  const r = await fetch("/api/reference/" + encodeURIComponent(melody.value));
  if (!r.ok) throw new Error("The reference melody could not be loaded.");
  const url = URL.createObjectURL(await r.blob());
  const audio = new Audio(url);
  await new Promise((resolve, reject) => { audio.onended = resolve; audio.onerror = reject; audio.play().catch(reject); });
  URL.revokeObjectURL(url);
}

async function beep(times) {
  const ctx = new AudioContext();
  for (let i = 0; i < times; i++) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.value = 880; g.gain.value = 0.2;
    o.connect(g); g.connect(ctx.destination); o.start();
    await sleep(180); o.stop(); await sleep(150);
  }
  await ctx.close();
}

async function playReference() {
  state = "playing"; refresh(); say("Playing the reference melody.");
  try { await playRef(); say("The reference melody has finished."); }
  catch { say("The reference melody could not be played."); }
  idle();
}

// ---- recording: raw audio to WAV, no extra converter needed ----
async function openMic() {
  if (!navigator.mediaDevices || !window.AudioWorkletNode) {
    throw Object.assign(new Error("This browser cannot record here. Use Chrome or Edge, opened at http://127.0.0.1:8000."), { name: "Unsupported" });
  }
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
  });
  const ctx = new AudioContext();
  const code = "class R extends AudioWorkletProcessor{process(i){const c=i[0][0];if(c)this.port.postMessage(c.slice());return true}}registerProcessor('rec',R)";
  const modUrl = URL.createObjectURL(new Blob([code], { type: "application/javascript" }));
  await ctx.audioWorklet.addModule(modUrl);
  URL.revokeObjectURL(modUrl);
  const r = { stream, ctx, chunks: [], active: false, auto: false, heard: false, last: 0, t0: 0, stopping: false };
  const node = new AudioWorkletNode(ctx, "rec");
  node.port.onmessage = (e) => {
    if (!r.active) return;
    r.chunks.push(e.data);
    if (!r.auto || r.stopping) return;
    let s = 0; for (const x of e.data) s += x * x;
    const now = performance.now();
    if (Math.sqrt(s / e.data.length) > 0.01) { r.heard = true; r.last = now; }
    const quiet = r.heard && now - r.last > 2000;      // two seconds of silence after singing
    const noSound = !r.heard && now - r.t0 > 12000;    // nothing sung for 12 seconds
    if (quiet || noSound || now - r.t0 > 45000) { r.stopping = true; stopAndAnalyze(); }
  };
  const mute = ctx.createGain(); mute.gain.value = 0;  // keeps the audio graph running, makes no sound
  ctx.createMediaStreamSource(stream).connect(node);
  node.connect(mute); mute.connect(ctx.destination);
  return r;
}
function beginCapture(auto) {
  rec.active = true; rec.auto = auto; rec.t0 = rec.last = performance.now();
  state = "recording"; refresh();
}
function closeMic() {
  if (!rec) return;
  rec.stream.getTracks().forEach((t) => t.stop());
  rec.ctx.close().catch(() => {});
  rec = null;
}
function micMessage(err) {
  const n = err && err.name;
  return n === "NotAllowedError" ? "Microphone permission was denied. Allow the microphone for this page in the browser, then try again."
    : n === "NotFoundError" ? "No microphone was found. Connect one and try again."
    : (err && err.message) || "Recording could not start.";
}

function encodeWav(chunks, total, rate) {
  const buf = new ArrayBuffer(44 + total * 2), v = new DataView(buf);
  const str = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  str(0, "RIFF"); v.setUint32(4, 36 + total * 2, true); str(8, "WAVE"); str(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  str(36, "data"); v.setUint32(40, total * 2, true);
  let o = 44;
  for (const c of chunks) for (let i = 0; i < c.length; i++, o += 2) {
    const s = Math.max(-1, Math.min(1, c[i]));
    v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Blob([buf], { type: "audio/wav" });
}

function finish(result) { if (onResult) { onResult(result); onResult = null; } }

async function stopAndAnalyze() {
  if (!rec) return;
  const { chunks, auto } = rec; rec.active = false;
  const sampleRate = rec.ctx.sampleRate;
  state = "busy"; refresh();
  closeMic();
  if (auto) await beep(1);   // one beep tells the singer the recording has ended
  const total = chunks.reduce((n, c) => n + c.length, 0);
  if (total < sampleRate) {
    say(NOTHING); finish({ simple: NOTHING }); idle(); return;
  }
  if (inSession) talk("Thank you. I am checking your singing now.");
  else say("Analyzing your singing. This takes a few seconds.");
  const form = new FormData();
  form.append("file", encodeWav(chunks, total, sampleRate), "recording.wav");
  form.append("melody", melody.value);
  form.append("mode", mode.value);
  try {
    const r = await fetch("/api/analyze/singing", { method: "POST", body: form });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.detail || "The server could not analyze the recording.");
    const notes = data.detected_notes.length ? " Notes heard: " + data.detected_notes.join(", ") + "." : "";
    details.textContent = data.feedback + notes;
    say(data.simple);
    finish({ simple: data.simple });
  } catch (err) { say("Analysis failed. " + err.message); finish(null); }
  idle();
}

async function startRecording() {
  state = "busy"; refresh(); say("Waiting for the microphone.");
  try {
    rec = await openMic();
    beginCapture(false);
    say("Recording. Sing the melody, then press Stop and analyze.");
  } catch (err) { closeMic(); idle(); say(micMessage(err)); }
}

// One press: listen, two beeps, record until silence, analyze.
async function practice() {
  state = "busy"; refresh();
  say("Listen to the melody. After two beeps, sing it. Recording stops after two seconds of silence.");
  try {
    rec = await openMic();
    await sleep(speak.checked ? 7000 : 4500);   // time for the message to be heard before the melody starts
    state = "playing"; refresh();
    await playRef();
    await sleep(500);
    await beep(2);
    beginCapture(true);
  } catch (err) { closeMic(); idle(); say(micMessage(err)); }
}

// ---- voice session: questions answered by voice or by a key ----
let srError = "";
function listenOnce(options) {
  return new Promise((resolve) => {
    let done = false, rc = null, timer;
    const end = (v) => {
      if (done) return;
      done = true; clearTimeout(timer); abortListen = null;
      document.removeEventListener("keydown", onKey);
      try { rc && rc.stop(); } catch {}
      resolve(v);
    };
    const onKey = (e) => {
      const o = options.find((x) => x.key === e.key.toLowerCase());
      if (o) { e.preventDefault(); end(o.value); }
    };
    abortListen = () => end(null);
    document.addEventListener("keydown", onKey);
    timer = setTimeout(() => end(null), 9000);
    if (!SR) return;
    rc = new SR(); rc.lang = navigator.language || "en-US"; rc.maxAlternatives = 3;
    rc.onresult = (e) => {
      const heard = [...e.results[0]].map((a) => a.transcript.toLowerCase()).join(" ");
      const o = options.find((x) => x.words.some((w) => new RegExp("\\b" + w + "\\b").test(heard)));
      end(o ? o.value : null);
    };
    rc.onerror = (e) => { srError = e.error || ""; };
    rc.onend = () => end(null);
    try { rc.start(); } catch {}
  });
}

async function ask(question, options) {
  for (let i = 0; i < 3; i++) {
    let q = i ? "Sorry, I did not catch that. " + question : question;
    if (i && srError === "network") q = "Voice answers need an internet connection. You can press the keys instead. " + question;
    await talk(q); guard();
    await beep(1); guard();
    const v = await listenOnce(options); guard();
    if (v) return v;
  }
  return null;
}

const YES_NO = [
  { value: "yes", key: "y", words: ["yes", "yeah", "yep", "okay", "ok", "sure", "ready"] },
  { value: "no", key: "n", words: ["no", "nope"] },
];
const MELODY_OPTS = [
  { value: "c_major_up", key: "1", words: ["one", "1", "up", "first"] },
  { value: "c_major_down", key: "2", words: ["two", "2", "to", "too", "down", "second"] },
  { value: "mary_lamb", key: "3", words: ["three", "3", "mary", "lamb", "third"] },
];

async function attempt() {
  try {
    rec = await openMic(); guard();
    await playRef(); guard();
    await sleep(500); await beep(2); guard();
  } catch (err) { closeMic(); if (!cancelled) await talk(micMessage(err)); return null; }
  const done = new Promise((res) => { onResult = res; });
  beginCapture(true);
  return done;
}

async function session() {
  await talk("Welcome to MelodyMate. I will help you practice singing. I will ask you questions. " +
    (SR ? "Answer by speaking after the beep, or press the key I name. " : "Answer by pressing the key I name. ") +
    "Press Escape at any time to stop.");
  guard();
  let on = null;
  for (let i = 0; i < 3 && on !== "yes"; i++) {
    on = await ask("Are you wearing headphones? Say yes, or press Y. Say no, or press N.", YES_NO);
    if (on === "no") await talk("Please put on your headphones first. Without them, the microphone hears the melody.");
    guard();
  }
  if (on !== "yes") return "I could not confirm your headphones. Goodbye.";
  mode.value = "relative";   // beginners may sing in any key
  for (;;) {
    const m = await ask("Which melody? Say one, or press 1, for a C major scale going up. " +
      "Say two, or press 2, for the scale going down. Say three, or press 3, for Mary Had a Little Lamb.", MELODY_OPTS);
    if (!m) return "I did not hear a choice. Goodbye.";
    melody.value = m;
    for (;;) {
      await talk("Listen to the melody first. Then, after two beeps, sing it. I will stop listening when you are quiet for two seconds.");
      guard();
      const res = await attempt(); guard();
      if (!res) return "The recording did not work. Goodbye.";
      let again = true;
      for (let i = 0; i < 3 && again; i++) {
        await talk(res.simple); guard();
        again = (await ask("Would you like to hear that again? Say yes or no.", YES_NO)) === "yes";
      }
      if ((await ask("Would you like to sing it again? Say yes or no.", YES_NO)) !== "yes") break;
    }
    if ((await ask("Would you like to try a different melody? Say yes or no.", YES_NO)) !== "yes") {
      return "Well done for practicing. Goodbye.";
    }
  }
}

async function voiceSession() {
  inSession = true; cancelled = false; state = "busy"; refresh();
  status.setAttribute("aria-live", "off");   // the session speaks for itself, so the screen reader stays quiet
  let ending = "";
  try { ending = await session(); await talk(ending); }
  catch (err) { ending = cancelled ? "Voice session stopped." : "Sorry, something went wrong. " + (err.message || ""); }
  finally {
    inSession = false; closeMic(); state = "idle"; refresh();
    status.setAttribute("aria-live", "polite");
  }
  status.textContent = ending;
}

document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape" || !inSession) return;
  cancelled = true; talkToken++;
  if ("speechSynthesis" in window) speechSynthesis.cancel();
  if (abortListen) abortListen();
  finish(null); closeMic();
});

onPress(voiceBtn, () => "Wait until the current step has finished.", voiceSession);
onPress(practiceBtn, idleReason, practice);
onPress(play, () => "Wait until the current step has finished.", playReference);
onPress(start, idleReason, startRecording);
onPress(stop, () => "Recording has not started.", stopAndAnalyze);
phones.addEventListener("change", refresh);
loadMelodies(); refresh();

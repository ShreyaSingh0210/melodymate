// MelodyMate singing page. Feedback goes only into #status (an aria-live region).
// Focus is never moved by this script. Nothing plays or records unless a button is pressed.
const $ = (id) => document.getElementById(id);
const status = $("status");
const melody = $("melody"), mode = $("mode"), phones = $("phones");
const play = $("play"), start = $("start"), stop = $("stop");
let state = "idle"; // idle | busy | playing | recording
let rec = null;

const say = (text) => { status.textContent = text; };
const setOn = (btn, on) => btn.setAttribute("aria-disabled", on ? "false" : "true");

function refresh() {
  setOn(play, state === "idle");
  setOn(start, state === "idle" && phones.checked);
  setOn(stop, state === "recording");
}

// aria-disabled keeps the button focusable, so focus never jumps when a button turns off.
function onPress(btn, reason, fn) {
  btn.addEventListener("click", () => {
    if (btn.getAttribute("aria-disabled") === "true") { say(reason()); return; }
    fn();
  });
}

async function loadMelodies() {
  try {
    const list = await (await fetch("/api/melodies")).json();
    list.forEach((m) => melody.add(new Option(m.label, m.id)));
  } catch { say("The melody list could not be loaded. Check that the server is running."); }
}

async function playReference() {
  state = "playing"; refresh(); say("Playing the reference melody.");
  try {
    const r = await fetch("/api/reference/" + encodeURIComponent(melody.value));
    if (!r.ok) throw new Error();
    const url = URL.createObjectURL(await r.blob());
    const audio = new Audio(url);
    audio.onended = () => { URL.revokeObjectURL(url); state = "idle"; refresh(); say("The reference melody has finished."); };
    await audio.play();
  } catch { state = "idle"; refresh(); say("The reference melody could not be played."); }
}

async function startRecording() {
  if (!navigator.mediaDevices || !window.AudioWorkletNode) {
    say("This browser cannot record here. Use a current version of Chrome or Edge, opened at http://127.0.0.1:8000."); return;
  }
  state = "busy"; refresh(); say("Waiting for the microphone.");
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
    });
    const ctx = new AudioContext();
    const code = "class R extends AudioWorkletProcessor{process(i){const c=i[0][0];if(c)this.port.postMessage(c.slice());return true}}registerProcessor('rec',R)";
    const modUrl = URL.createObjectURL(new Blob([code], { type: "application/javascript" }));
    await ctx.audioWorklet.addModule(modUrl);
    URL.revokeObjectURL(modUrl);
    const node = new AudioWorkletNode(ctx, "rec");
    const mute = ctx.createGain(); mute.gain.value = 0; // keeps the graph running, makes no sound
    const chunks = [];
    node.port.onmessage = (e) => chunks.push(e.data);
    ctx.createMediaStreamSource(stream).connect(node);
    node.connect(mute); mute.connect(ctx.destination);
    rec = { stream, ctx, chunks };
    state = "recording"; refresh();
    say("Recording. Sing the melody, then press Stop and analyze.");
  } catch (err) {
    state = "idle"; refresh();
    const n = err && err.name;
    say(n === "NotAllowedError" ? "Microphone permission was denied. Allow the microphone for this page in the browser, then try again."
      : n === "NotFoundError" ? "No microphone was found. Connect one and try again."
      : "Recording could not start. " + ((err && err.message) || ""));
  }
}

function encodeWav(chunks, total, rate) {
  const buf = new ArrayBuffer(44 + total * 2), v = new DataView(buf);
  const str = (o, s) => [...s].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  str(0, "RIFF"); v.setUint32(4, 36 + total * 2, true); str(8, "WAVE"); str(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
  str(36, "data"); v.setUint32(40, total * 2, true);
  let o = 44;
  for (const c of chunks) for (let i = 0; i < c.length; i++, o += 2) {
    const s = Math.max(-1, Math.min(1, c[i]));
    v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Blob([buf], { type: "audio/wav" });
}

async function stopAndAnalyze() {
  const { stream, ctx, chunks } = rec; rec = null;
  state = "busy"; refresh();
  stream.getTracks().forEach((t) => t.stop());
  const rate = ctx.sampleRate;
  await ctx.close();
  const total = chunks.reduce((n, c) => n + c.length, 0);
  if (total < rate) {
    state = "idle"; refresh();
    say("The recording was shorter than one second. Press Start recording and try again."); return;
  }
  say("Analyzing your singing. This takes a few seconds.");
  const form = new FormData();
  form.append("file", encodeWav(chunks, total, rate), "recording.wav");
  form.append("melody", melody.value);
  form.append("mode", mode.value);
  try {
    const r = await fetch("/api/analyze/singing", { method: "POST", body: form });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.detail || "The server could not analyze the recording.");
    const notes = data.detected_notes.length ? " Notes heard: " + data.detected_notes.join(", ") + "." : "";
    say(data.feedback + notes);
  } catch (err) { say("Analysis failed. " + err.message); }
  state = "idle"; refresh();
}

onPress(play, () => "Wait until the current step has finished.", playReference);
onPress(start, () => state === "idle"
  ? "Tick the headphones box first. Without headphones, the microphone hears the reference melody."
  : "Wait until the current step has finished.", startRecording);
onPress(stop, () => "Recording has not started.", stopAndAnalyze);
phones.addEventListener("change", refresh);
loadMelodies(); refresh();
